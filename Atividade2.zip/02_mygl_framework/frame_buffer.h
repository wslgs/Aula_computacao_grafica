#ifndef FRAME_BUFFER_H
#define FRAME_BUFFER_H

// Ponteiro para o primeiro byte do color buffer.
unsigned char* fb_ptr;
unsigned char* flipped_buff_ptr; //  flipped buffer

#endif  // FRAME_BUFFER_H
