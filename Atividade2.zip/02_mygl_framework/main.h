#ifndef MAIN_H
#define MAIN_H

#include <GL/glut.h>
#include <stdio.h>

#include "core.h"
#include "mygl.h"

#endif  // MAIN_H
