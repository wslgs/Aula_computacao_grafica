#ifndef CORE_H
#define CORE_H

#define IMAGE_WIDTH 512   // número de colunas da imagem.
#define IMAGE_HEIGHT 512 // número de linhas da imagem.

#endif  // CORE_H
